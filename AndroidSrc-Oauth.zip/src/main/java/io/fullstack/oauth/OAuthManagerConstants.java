package io.fullstack.oauth;

public interface OAuthManagerConstants {
  String CREDENTIALS_STORE_PREF_FILE = "oauth_manager";
}